//
//  LaunchManager.swift
//  Odysseus
//
//  Created by Christian on 6/6/26.
//

import Foundation
import AppKit
import Combine

class LaunchManager: ObservableObject {
    @Published var status: LaunchStatus = .starting
    @Published var odysseusVersion: String = "Checking..."

    enum LaunchStatus {
        case starting
        case waitingForServer
        case ready
        case failed
        case ollamaNotFound
    }

    init() {
        refreshOdysseusVersion()
    }
    
    var useTerminalOllama: Bool {
        UserDefaults.standard.bool(forKey: "useTerminalOllama")
    }

    func refreshOdysseusVersion() {
        DispatchQueue.global().async {
            let process = Process()
            process.launchPath = "/bin/bash"
            process.arguments = [
                "-c",
                "cd /Users/christianlayman/odysseus && git log -1 --format='%h • %cd' --date=format:'%b %d %Y' 2>/dev/null || echo 'Unknown'"
            ]
            process.environment = self.enrichedEnvironment()

            let pipe = Pipe()
            process.standardOutput = pipe
            process.launch()
            process.waitUntilExit()

            let output = String(
                data: pipe.fileHandleForReading.readDataToEndOfFile(),
                encoding: .utf8
            )?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"

            DispatchQueue.main.async {
                self.odysseusVersion = output
            }
        }
    }

    func start() {
        NotificationCenter.default.removeObserver(
            self,
            name: NSApplication.willTerminateNotification,
            object: nil
        )

        status = .starting
        DispatchQueue.global().async {
            guard self.launchOllama() else {
                DispatchQueue.main.async { self.status = .ollamaNotFound }
                return
            }
            self.launchOdysseus()
            self.waitForServer()
        }

        NotificationCenter.default.addObserver(
            forName: NSApplication.willTerminateNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.killOdysseus()
        }
    }

    func killOdysseus() {
        let kill = Process()
        kill.launchPath = "/bin/bash"
        kill.arguments = [
            "-c",
            "pkill -f 'uvicorn'; /opt/homebrew/bin/tmux kill-session -t odysseus 2>/dev/null; sleep 1"
        ]
        kill.environment = enrichedEnvironment()
        kill.launch()
        kill.waitUntilExit()

        DispatchQueue.main.async {
            self.status = .failed
        }
    }

    func enrichedEnvironment() -> [String: String] {
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
        env["HOME"] = "/Users/christianlayman"
        env["ODYSSEUS_NO_OPEN"] = "1"
        return env
    }

    // Returns false if Ollama couldn't be launched
    @discardableResult
    private func launchOllama() -> Bool {
        let ollamaRunning = Process()
        ollamaRunning.launchPath = "/bin/bash"
        ollamaRunning.arguments = ["-c", "pgrep -x ollama > /dev/null"]
        ollamaRunning.environment = enrichedEnvironment()
        ollamaRunning.launch()
        ollamaRunning.waitUntilExit()

        if useTerminalOllama {
            // Already running, nothing to do
            if ollamaRunning.terminationStatus == 0 { return true }

            let serve = Process()
            serve.launchPath = "/bin/bash"
            serve.arguments = ["-c", "/opt/homebrew/bin/ollama serve > /tmp/ollama.log 2>&1 &"]
            serve.environment = enrichedEnvironment()
            serve.launch()
            
            // Wait longer for brew ollama to initialize
            Thread.sleep(forTimeInterval: 4.0)

            let verify = Process()
            verify.launchPath = "/bin/bash"
            verify.arguments = ["-c", "pgrep -x ollama > /dev/null"]
            verify.environment = enrichedEnvironment()
            verify.launch()
            verify.waitUntilExit()
            return verify.terminationStatus == 0

        } else {
            // App mode — kill any headless ollama first so the app takes over
            if ollamaRunning.terminationStatus == 0 {
                let kill = Process()
                kill.launchPath = "/bin/bash"
                kill.arguments = ["-c", "pkill -x ollama"]
                kill.environment = enrichedEnvironment()
                kill.launch()
                kill.waitUntilExit()
                Thread.sleep(forTimeInterval: 1.0)
            }

            let ollamaAppURL = URL(fileURLWithPath: "/Applications/Ollama.app")
            guard FileManager.default.fileExists(atPath: ollamaAppURL.path) else {
                return false
            }

            let config = NSWorkspace.OpenConfiguration()
            config.activates = false
            NSWorkspace.shared.openApplication(
                at: ollamaAppURL,
                configuration: config
            )
            Thread.sleep(forTimeInterval: 2.0)

            let verify = Process()
            verify.launchPath = "/bin/bash"
            verify.arguments = ["-c", "pgrep -x ollama > /dev/null"]
            verify.environment = enrichedEnvironment()
            verify.launch()
            verify.waitUntilExit()
            return verify.terminationStatus == 0
        }
    }

    private func launchOdysseus() {
        let odysseusRunning = Process()
        odysseusRunning.launchPath = "/bin/bash"
        odysseusRunning.arguments = ["-c", "pgrep -f 'uvicorn' > /dev/null"]
        odysseusRunning.environment = enrichedEnvironment()
        odysseusRunning.launch()
        odysseusRunning.waitUntilExit()

        guard odysseusRunning.terminationStatus != 0 else { return }

        let process = Process()
        process.launchPath = "/opt/homebrew/bin/tmux"
        process.arguments = [
            "new-session", "-d", "-s", "odysseus",
            "bash", "-c",
            "cd /Users/christianlayman/odysseus && ./start-macos.sh"
        ]
        process.environment = enrichedEnvironment()
        process.launch()
        process.waitUntilExit()
    }

    private func waitForServer(retries: Int = 30, delay: TimeInterval = 2.0) {
        DispatchQueue.main.async { self.status = .waitingForServer }

        for _ in 0..<retries {
            if serverIsReachable() {
                DispatchQueue.main.async { self.status = .ready }
                return
            }
            Thread.sleep(forTimeInterval: delay)
        }
        DispatchQueue.main.async { self.status = .failed }
    }

    private func serverIsReachable() -> Bool {
        guard let url = URL(string: "http://127.0.0.1:7860") else { return false }
        var request = URLRequest(url: url)
        request.timeoutInterval = 3.0
        var reachable = false
        let semaphore = DispatchSemaphore(value: 0)

        URLSession.shared.dataTask(with: request) { _, response, _ in
            if let http = response as? HTTPURLResponse, http.statusCode == 200 {
                reachable = true
            }
            semaphore.signal()
        }.resume()

        semaphore.wait()
        return reachable
    }
}
