//
//  PreferencesView.swift
//  Athena
//
//  Created by Christian on 6/6/26.
//

import SwiftUI

struct PreferencesView: View {
    @EnvironmentObject var launcher: LaunchManager
    @AppStorage("clearCredentialsOnClose") var clearCredentialsOnClose: Bool = false
    @AppStorage("useTerminalOllama") var useTerminalOllama: Bool = false
    @State private var showingKillConfirmation = false
    @State private var updateStatus: UpdateStatus = .idle

    enum UpdateStatus: Equatable {
        case idle
        case checking
        case upToDate
        case updated(String)
        case failed(String)
    }

    var serverIsRunning: Bool {
        launcher.status == .ready
    }

    var athenaVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "Unknown"
    }

    var body: some View {
        Form {
            Section("About") {
                HStack {
                    Text("Athena Version")
                    Spacer()
                    Text(athenaVersion)
                        .foregroundColor(.secondary)
                }

                HStack {
                    Text("Odysseus Version")
                    Spacer()
                    Text(launcher.odysseusVersion)
                        .foregroundColor(.secondary)
                }

                HStack {
                    Button {
                        checkForUpdates()
                    } label: {
                        Label("Check for Odysseus Updates", systemImage: "arrow.clockwise")
                    }
                    .disabled(updateStatus == .checking)

                    Spacer()

                    switch updateStatus {
                    case .idle:
                        EmptyView()
                    case .checking:
                        ProgressView()
                            .scaleEffect(0.7)
                    case .upToDate:
                        Label("Up to date", systemImage: "checkmark.circle.fill")
                            .foregroundColor(.green)
                            .font(.caption)
                    case .updated(let msg):
                        Label(msg, systemImage: "checkmark.circle.fill")
                            .foregroundColor(.blue)
                            .font(.caption)
                    case .failed(let msg):
                        Label(msg, systemImage: "exclamationmark.triangle.fill")
                            .foregroundColor(.orange)
                            .font(.caption)
                    }
                }

                Text("Restart Athena after updating to apply changes.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Section("Ollama") {
                Toggle("Use Terminal Ollama", isOn: $useTerminalOllama)
                Text("Enable this if you installed Ollama via Homebrew instead of downloading the app. This will run 'ollama serve' in the background on launch.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Section("Session") {
                Toggle("Clear login credentials on close", isOn: $clearCredentialsOnClose)
                Text("Clears login credentials each time the app quits, forcing login on next launch.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Section("Server") {
                if serverIsRunning {
                    Button(role: .destructive) {
                        showingKillConfirmation = true
                    } label: {
                        Label("Stop Odysseus Server", systemImage: "stop.circle")
                    }
                } else {
                    Button {
                        launcher.start()
                    } label: {
                        Label("Launch Odysseus Server", systemImage: "play.circle")
                    }
                    .buttonStyle(.borderedProminent)
                }

                Text("The server can also be stopped at any time by pressing Cmd+Q while in the app.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .formStyle(.grouped)
        .frame(width: 440, height: 520)
        .padding()
        .confirmationDialog(
            "Stop Odysseus Server?",
            isPresented: $showingKillConfirmation,
            titleVisibility: .visible
        ) {
            Button("Stop Server", role: .destructive) {
                launcher.killOdysseus()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This will shut down the Odysseus server. The main window will return to the launch screen.")
        }
    }

    private func checkForUpdates() {
        updateStatus = .checking
        DispatchQueue.global().async {
            let process = Process()
            process.launchPath = "/bin/bash"
            process.arguments = ["-c", "cd /Users/christianlayman/odysseus && git pull 2>&1"]
            process.environment = enrichedEnvironment()

            let pipe = Pipe()
            process.standardOutput = pipe
            process.standardError = pipe
            process.launch()
            process.waitUntilExit()

            let output = String(
                data: pipe.fileHandleForReading.readDataToEndOfFile(),
                encoding: .utf8
            ) ?? ""

            DispatchQueue.main.async {
                launcher.refreshOdysseusVersion()
                if output.contains("Already up to date") {
                    updateStatus = .upToDate
                } else if process.terminationStatus == 0 {
                    updateStatus = .updated("Updated — restart to apply")
                } else {
                    updateStatus = .failed("Update failed")
                }
            }
        }
    }

    private func enrichedEnvironment() -> [String: String] {
        var env = ProcessInfo.processInfo.environment
        env["PATH"] = "/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
        env["HOME"] = "/Users/christianlayman"
        return env
    }
}
