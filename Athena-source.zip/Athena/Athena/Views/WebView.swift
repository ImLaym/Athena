//
//  WebView.swift
//  Athena
//
//  Created by Christian on 6/5/26.
//

import SwiftUI
import WebKit

struct WebView: NSViewRepresentable {
    let url: URL
    @AppStorage("clearCredentialsOnClose") var clearCredentialsOnClose: Bool = false

    func makeNSView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = clearCredentialsOnClose
            ? WKWebsiteDataStore.nonPersistent()
            : WKWebsiteDataStore.default()

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.load(URLRequest(url: url))

        NotificationCenter.default.addObserver(
            forName: NSApplication.willTerminateNotification,
            object: nil,
            queue: .main
        ) { _ in
            if clearCredentialsOnClose {
                WKWebsiteDataStore.default().removeData(
                    ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(),
                    modifiedSince: .distantPast
                ) {}
            }
        }

        return webView
    }

    func updateNSView(_ nsView: WKWebView, context: Context) {}
}
