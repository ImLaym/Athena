//
//  ContentView.swift
//  Athena
//
//  Created by Christian on 6/5/26.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var launcher: LaunchManager

    var body: some View {
        Group {
            switch launcher.status {
            case .starting:
                startupView(
                    icon: "gearshape.2.fill",
                    message: "Starting Ollama and Odysseus...",
                    showRetry: false,
                    showOllamaHelp: false
                )

            case .waitingForServer:
                startupView(
                    icon: "clock.fill",
                    message: "Waiting for Odysseus to come online...",
                    showRetry: false,
                    showOllamaHelp: false
                )

            case .ready:
                WebView(url: URL(string: "http://127.0.0.1:7860")!)

            case .failed:
                startupView(
                    icon: "exclamationmark.triangle.fill",
                    message: "Odysseus didn't start in time.\nCheck that start-macos.sh is working and try again.",
                    showRetry: true,
                    showOllamaHelp: false
                )

            case .ollamaNotFound:
                startupView(
                    icon: "exclamationmark.triangle.fill",
                    message: "",
                    showRetry: true,
                    showOllamaHelp: true
                )
            }
        }
        .frame(minWidth: 900, minHeight: 600)
        .onAppear {
            launcher.start()
        }
    }

    @ViewBuilder
    private func startupView(icon: String, message: String, showRetry: Bool, showOllamaHelp: Bool) -> some View {
        VStack(spacing: 20) {
            Image(systemName: icon)
                .font(.system(size: 48))
                .foregroundColor(.secondary)

            if showOllamaHelp {
                VStack(spacing: 12) {
                    Text("Ollama couldn't launch.")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)

                    Text("Please ensure you have Ollama downloaded.")
                        .foregroundColor(.secondary)

                    Divider()
                        .frame(width: 400)

                    Text("By default, Athena is set up for the Ollama app.")
                        .foregroundColor(.secondary)

                    Link("Download Ollama free at ollama.com",
                         destination: URL(string: "https://ollama.com")!)
                        .font(.callout)

                    Divider()
                        .frame(width: 400)

                    Text("If you installed Ollama via Homebrew, open Odysseus → Settings in the top bar and enable \"Use Terminal Ollama\", then restart the app.")
                        .multilineTextAlignment(.center)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: 480)
                }
                .padding()
            } else {
                Text(message)
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
            }

            if showRetry {
                Button("Retry") {
                    launcher.start()
                }
                .buttonStyle(.borderedProminent)
            } else {
                ProgressView()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(NSColor.windowBackgroundColor))
    }
}
