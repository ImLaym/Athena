//
//  AthenaApp.swift
//  Athena
//
//  Created by Christian on 6/5/26.
//

import SwiftUI

@main
struct AthenaApp: App {
    @StateObject private var launcher = LaunchManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(launcher)
        }

        Settings {
            PreferencesView()
                .environmentObject(launcher)
        }
    }
}
